The original ZAP lightning bolt logo was designed by a.c.neumann at
https://github.com/zaproxy/zaproxy/issues/74#issuecomment-108865883

The EPS of the vector design was updated to larger 1024 and 512 sizes
and had some color correction performed to look nicer on new retina Mac
displays by Benjamin Slack of http://www.nimajneb.com/ .  

The new logo was designed by Lisa Raynaud in 2017 as part of the design of the new ZAP website.

The png, ico, and icns files are all present in the resources folder.
